module.exports=[45968,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_galerie_page_actions_0rwh68_.js.map