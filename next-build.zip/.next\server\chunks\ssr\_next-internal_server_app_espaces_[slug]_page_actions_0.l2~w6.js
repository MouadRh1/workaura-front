module.exports=[42767,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_espaces_%5Bslug%5D_page_actions_0.l2~w6.js.map