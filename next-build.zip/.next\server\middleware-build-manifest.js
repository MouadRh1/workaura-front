globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/build-1781003012891/_buildManifest.js",
    "static/build-1781003012891/_ssgManifest.js",
    "static/build-1781003012891/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/16fce0~0kfr7_.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0c7h~x4_chf35.js",
    "static/chunks/turbopack-0suh2y9e3maot.js"
  ]
};
