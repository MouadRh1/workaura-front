1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/028bam7jorywn.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0w4r12wr241f2.js","/_next/static/chunks/0nehb6gnwk_5_.js"],"default"]
3:I[37457,["/_next/static/chunks/028bam7jorywn.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0w4r12wr241f2.js","/_next/static/chunks/0nehb6gnwk_5_.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"build-1781003012891"}
