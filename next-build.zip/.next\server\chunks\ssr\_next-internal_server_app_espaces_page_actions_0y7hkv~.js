module.exports=[38772,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_espaces_page_actions_0y7hkv~.js.map